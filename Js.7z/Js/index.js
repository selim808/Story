var output;
class Node {
  constructor(key) {
    this.value = key;
    this.left = null;
    this.right = null;
  }
}

class BinaryTree {
  constructor() {
    this.root = null;
  }
  insert(key) {
    var newNode = new Node(key);
    if (this.root === null) {
      //{2}
      this.root = newNode;
    } else {
      insertNode(this.root, newNode); //{3}
    }

    function insertNode(node, newNode) {
      if (newNode.value < node.value) {
        //{4}
        if (node.left === null) {
          //{5}
          node.left = newNode; //{6}
        } else {
          insertNode(node.left, newNode); //{7}
        }
      } else {
        if (node.right === null) {
          //{8}
          node.right = newNode; //{9}
        } else {
          insertNode(node.right, newNode); //{10}
        }
      }
    }
  }
  inorderTraverse(callback) {
    inorderTraverseNode(this.root, callback);
    function inorderTraverseNode(node, callback) {
      if (node !== null) {
        // console.log("Recursion Start");
        inorderTraverseNode(node.left, callback);
        callback(node.value);
        inorderTraverseNode(node.right, callback);
      } else {
        // console.log("Recursion Stop");
      }
    }
  }
  preorderTraverse(callback) {
    preorderTraverseNode(this.root, callback);
    function preorderTraverseNode(node, callback) {
      if (node !== null) {
        // console.log("Recursion Start");
        callback(node.value);
        preorderTraverseNode(node.left, callback);
        preorderTraverseNode(node.right, callback);
      } else {
        // console.log("Recursion Stop");
      }
    }
  }
  postorderTraverse(callback) {
    postorderTraverseNode(this.root, callback);
    function postorderTraverseNode(node, callback) {
      if (node !== null) {
        // console.log("Recursion Start");
        postorderTraverseNode(node.left, callback);
        postorderTraverseNode(node.right, callback);
        callback(node.value);
      } else {
        // console.log("Recursion Stop");
      }
    }
  }
  min() {
    function minimum(node) {
      while (node && node.left !== null) {
        node = node.left;
      }
      return node.value;
    }
    return minimum(this.root);
  }
  max() {
    function maximum(node) {
      while (node && node.right !== null) {
        node = node.right;
      }
      return node.value;
    }
    return maximum(this.root);
  }
  search(key) {
    function searchNode(node, key) {
      if (node === null) {
        return false;
      }
      if (key < node.value) {
        return searchNode(node.left, key);
      } else if (key > node.value) {
        return searchNode(node.right, key);
      } else {
        return true;
      }
    }
    return searchNode(this.root, key);
  }
}

function printTree(x) {
  console.log(x);
}

var tree = new BinaryTree();

tree.insert(5);
tree.insert(4);
tree.insert(7);
tree.insert(2);
tree.insert(1);
tree.insert(3);
tree.insert(6);
tree.insert(8);
tree.insert(9);

tree.inorderTraverse(printTree);
console.log(
  "______________________________________________________________________________________________________"
);
tree.preorderTraverse(printTree);
console.log(
  "______________________________________________________________________________________________________"
);
tree.postorderTraverse(printTree);
console.log(
  "______________________________________________________________________________________________________"
);

console.log(tree.min());
console.log(tree.max());
console.log(tree.search(5));
console.log(tree.search(11));

/* 
Tree traversal : Traversing (or walking) a tree is the process of visiting all the nodes of a tree and  
performing an operation at each node.

There are three different approaches that can be used to visit all the nodes in a tree: 
inorder: Ascending value order. 
pre-order: node then descendants, finish all childeren before next node.
post-order: descendats then node, write all below then node.

*/

output = tree;
console.log(output);
